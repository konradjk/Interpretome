Sun, 07 Aug 2011  14:00

This is a text file, that will be compressed,
and embedded into a zip file.

It uses a utf8-encoded filename in the zip, to store the copyright
symbol.

This is used only as a demonstration that the UTF8-aware filename
decoding in the ZipFile.js class, is working.

That's all for now.



